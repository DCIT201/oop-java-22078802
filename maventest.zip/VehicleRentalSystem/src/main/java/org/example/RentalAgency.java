package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class RentalAgency {
    private String name;
    private Map<String, Vehicle> vehicleFleet;
    private List<RentalTransaction> transactions;

    public RentalAgency(String name) {
        this.name = name;
        this.vehicleFleet = new HashMap<>();
        this.transactions = new ArrayList<>();
    }

    public void addVehicle(Vehicle vehicle) {
        vehicleFleet.put(vehicle.getvehicleId(), vehicle);
    }

    public void rentVehicle(String vehicleId, Customer customer, int days) {
        Vehicle vehicle = vehicleFleet.get(vehicleId);
        if (vehicle != null && vehicle.isAvailableForRental()) {
            vehicle.setisAvailable(false);
            double cost = vehicle.calculateRentalCost(days);
            RentalTransaction transaction = new RentalTransaction(customer, vehicle, days, cost);
            transactions.add(transaction);
            customer.addRental(vehicle);
            System.out.println("Vehicle rented successfully. Total cost: " + cost);
        } else {
            System.out.println("Vehicle not available for rental.");
        }
    }

    public void returnVehicle(String vehicleId) {
        Vehicle vehicle = vehicleFleet.get(vehicleId);
        if (vehicle != null) {
            vehicle.setisAvailable(true);
            System.out.println("Vehicle returned successfully.");
        } else {
            System.out.println("Invalid vehicle ID.");
        }
    }

    public void generateReport() {
        System.out.println("Rental Agency Report:");
        for (RentalTransaction transaction : transactions) {
            System.out.println(transaction);
        }
    }
}
