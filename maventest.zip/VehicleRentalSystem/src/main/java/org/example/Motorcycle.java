package org.example;

public class Motorcycle extends Vehicle {
    private final double protectiveGear = 5;
    public Motorcycle (String vehicleId, String model, double baseRentalRate){
        super (vehicleId,model,baseRentalRate);
}
    @Override
    public double calculateRentalCost(int days) {
        return (getbaseRentalRate() + protectiveGear) * days;
    }
    @Override
    public boolean isAvailableForRental() {
        return isAvailable();
    }

}
