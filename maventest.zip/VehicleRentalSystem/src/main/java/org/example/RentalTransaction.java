package org.example;

class RentalTransaction {
    private Customer customer;
    private Vehicle vehicle;
    private int rentalDays;
    private double totalCost;

    public RentalTransaction(Customer customer, Vehicle vehicle, int rentalDays, double totalCost) {
        this.customer = customer;
        this.vehicle = vehicle;
        this.rentalDays = rentalDays;
        this.totalCost = totalCost;
    }

    @Override
    public String toString() {
        return "Customer: " + customer.getName() + ", Vehicle: " + vehicle.getModel() + ", Days: " + rentalDays + ", Cost: " + totalCost;
    }
}


    