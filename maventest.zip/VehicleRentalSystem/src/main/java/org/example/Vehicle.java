package org.example;

public abstract class Vehicle {
         // Private encapsulated fields
         private String vehicleId;
         private String model;
         private double baseRentalRate;
         private boolean isAvailable;
     
         // Constructors with validation
         // Abstract methods for rental calculation
         public Vehicle(String vehicleId, String model, double baseRentalRate) {
            this.vehicleId = vehicleId;
            this.model = model;
            this.baseRentalRate = baseRentalRate;
            this.isAvailable = true;
        }
         // Getters and setters
        public String getvehicleId(){
            return vehicleId;
        }
        public double getbaseRentalRate(){
            return baseRentalRate;
        }
        public boolean isAvailable(){
            return isAvailable;
        }
        public void setvehicleId(String vehicleId){
            this.vehicleId =vehicleId;
        }
        public void setmodel(String model){
            this.model =model;
        }
        public void setbaseRentalRate(double baseRentalRate){
            this.baseRentalRate =baseRentalRate;
        }
        public void setisAvailable(boolean available){
            this.isAvailable =available;
        }
        // Abstract methods for rental calculation
        public abstract double calculateRentalCost(int days);
        public abstract boolean isAvailableForRental();

    public String getModel() {
        return model;
    }

  
}
