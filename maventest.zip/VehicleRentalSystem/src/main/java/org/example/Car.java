package org.example;

class Car extends Vehicle {
    private final double insuranceRate = 10;
    public Car(String vehicleId, String model, double baseRentalRate) {
        super(vehicleId, model, baseRentalRate);
    }

    @Override
    public double calculateRentalCost(int days) {
        return (getbaseRentalRate() + insuranceRate) * days;
    }
    @Override
    public boolean isAvailableForRental() {
        return isAvailable();
    }

}
