package org.example;

public interface Rental {
   void  rent(Customer customer, int days);
   void returnVehicle();

}
