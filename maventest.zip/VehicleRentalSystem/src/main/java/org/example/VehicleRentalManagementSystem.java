package org.example;

public class VehicleRentalManagementSystem {
    public static void main(String[] args) {
        RentalAgency agency = new RentalAgency("QuickRent");

        Vehicle car = new Car("C001", "Toyota Camry", 50.0);
        Vehicle motorcycle = new Motorcycle("M001", "Harley Davidson", 30.0);
        Vehicle truck = new Truck("T001", "Ford F-150", 100.0);

        agency.addVehicle(car);
        agency.addVehicle(motorcycle);
        agency.addVehicle(truck);

        Customer customer = new Customer("John Doe", "CU001");

        agency.rentVehicle("C001", customer, 3); 
        agency.returnVehicle("C001"); 

        agency.generateReport(); 
    }

}
